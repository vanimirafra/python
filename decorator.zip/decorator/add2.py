def formatting(even):
	def formatting_real(func):
		def wrapper(a, b):
			if even%2==0:

				a = a * 10
				b = b * 20
				func(a, b)
			else:
				return func(a,b)
		return wrapper
	return formatting_real


@formatting(even = 7)
def add(a,b):
	print(a+b)

a=int(input("enter number"))
b=int(input('enter number'))
add(a,b)