with open("1.txt", "w") as f:
    data=f.write("h")
    print(data)
     
