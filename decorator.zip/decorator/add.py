def decorator(even):

    def smart_add(func):
        def inner(a,b):
            if even%2==0:
                a=a*10
                b=b*20
                func(a, b)
            else:
                func(a,b)

        return inner
    return smart_add

@decorator(even=2)
def add(a,b):
    print(a+b)

a=int(input("enter number"))
b=int(input('enter number'))
even=int(input("enter number"))
add(a,b)







