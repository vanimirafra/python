def multiply(by = None):
	def multiply_real_decorator(function):
		def inner(*args,**kwargs):
			return by * function(*args,**kwargs)
		return inner
	return multiply_real_decorator

@multiply(by = 3)
def adder(a,b):
	return a + b
a=int(input('enter number'))
b=int(input('enter number'))
print(adder(a,b))

