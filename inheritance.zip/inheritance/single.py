class Parent:
    def m1(self):
        print("parent method")

class Child(Parent):
    def m2(self):
        print("child method")

obj=Child()
obj.m2()
obj.m1()

