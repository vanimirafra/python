import re
text = "The film Titanic was    released in 1998"
result = re.match(r"[a-zA-z]+", text)
result = re.search(r"was", text)
result = re.sub(r"Titanic", "abc",  text)
result = re.sub(r"[a-z]", "X", text)
result = re.sub(r"[a-zA-Z]", "X", text)
result = re.sub(r"\d+", "X", text)
result = re.sub(r"[a-z]", " ", text)
result = re.sub(r"[a-zA-Z]", " ", text)
result = re.sub(r"\d+", " ", text)
result = re.sub(r"\s+", " ", text)
print(result)