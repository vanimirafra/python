d={1:"hi",2:"hai",3:"good",4:"bad"}
d.pop(2)
print(d)

