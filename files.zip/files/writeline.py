f=open("2.txt","w")
list=["vinny\n", "chinny\n"]
f.writelines(list)
f.close()




