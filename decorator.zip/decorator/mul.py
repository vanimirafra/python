def double(function):
	def wrapper(*args,**kwargs):

		return 10 * function(*args, **kwargs)
	return wrapper

@double
def adder(x,y,z):
	return x + y+z
x=int(input("enter number"))
y=int(input("enter number"))
z=int(input("enter number"))
print(adder(x,y,z))