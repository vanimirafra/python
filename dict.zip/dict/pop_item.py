d={1:"hi",2:"hai",3:"good",4:"bad"}
d.popitem()
print(d)
d.popitem()
print(d)


