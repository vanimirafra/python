import re
text = "The film      Pulp   Fiction was released in year 1994      "
result = re.split(r"\s+", text)
print(result)