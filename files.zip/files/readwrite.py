f=open("2.txt","w")
f.write("hello\n")
f.write("good\n")
f.write("morning\n")
f.close()
f=open("2.txt","r")
print(f)



