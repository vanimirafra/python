f = open("1.txt", "r")
print(f.readline())
print(f.readline())
f.close()

