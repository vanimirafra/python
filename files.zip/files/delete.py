import os
#os.remove("3.txt")
if os.path.exists("3.txt"):
    os.remove("3.txt")
else:
    print("the fail doesn't exist")

