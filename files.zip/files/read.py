f = open("1.txt", "r")
print(f.read())
f.close()
