import re


Nameage = '''
Jai is 22 and sri is 32
merry is 33 and john in31
'''
age = re.search('\d{1,3}', Nameage)
names = re.search('[A-Z][a-z]*', Nameage)
print(names.group(0))
