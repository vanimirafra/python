fname = input("Enter file name: ")
word = input("Enter word to be searched:")
k=0
with open(fname,'r') as f:
    d={}
    line_no={}
    count=0
    #li=[]
    for line in f:
        count +=1
        words=line.split()
        #print(words)
        for i in words:
            if i==word:
                k=k+1
                #d[word]=d.get(word,0)+1

                line_no.setdefault(word,[]).append(count)
            #print(line_no)
    print(k)
    print(line_no)