class A:
    def who_am_i(self):
        print("I am a A")

class B(A):
    pass
    

class C(A):
    def who_am_i(self):
        print("I am a C")

class D(B,C):
    pass    

d1 = D()
d1.who_am_i()
#print(D.__mro__)
#print(D.mro())
