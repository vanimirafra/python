d={10:56,34:78,67:99}
#print(d[15])
print(d[10])
print(d.get(20))
print(d.get(34))


