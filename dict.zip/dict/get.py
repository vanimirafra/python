d={1:"hi",2:"hai",3:"good",4:"bad"}

print(d.get(1))
print(d.get(2))
print(d.get(5))
print(d.get(5, 'not found'))

