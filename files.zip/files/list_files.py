import os
f=os.listdir("/home/mirafra/Downloads/Ticket")
print(f)

