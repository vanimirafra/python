f = open("1.txt", "r")
for x in f:
    print(x, end='')

