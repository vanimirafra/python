class A:
    def m1(self):
        print("m1 method")
class B(A):
    def m1(self):
        print("m2 method")
obj=B()
obj.m1()
