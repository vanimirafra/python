import re
pattern = 'b'
test_string = 'abyss'
result = re.search(pattern, test_string)
print(result.group(0))

'''if result:
  print("Search successful.")
else:
  print("Search unsuccessful.")'''
