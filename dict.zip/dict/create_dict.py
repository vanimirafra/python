d={}
d[100]="hai"
d[2]="hai"
print(d)

d={1:'hai', 2:'hello'}
print(d)
print(d[1])
print(d[2])
print(d[3])  #KeyError

