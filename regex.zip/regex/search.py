import re

result=re.search("i", "hello goodmorning")
if result:
    print("the hai is there")
else:
    print("nothing")

print(result.group(0))
