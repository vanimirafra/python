import re
string = 'Twelve:12 Eighty nine:89.'
pattern = 'nine'
result = re.split(pattern, string)
print(result)
