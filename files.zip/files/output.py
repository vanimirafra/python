f1=open("2.txt","r")
f2=open("output.txt", "w")
f2.write(f1.read())
f1.close()
f2.close()

