class A:
    def m1(self):
        print("m1 method")
class B(A):
    def m1(self):
        print("m2 method")
class C(A):
     def m1(self):
        print("m3 method")
class D(C,B):
    pass
obj=D()
obj.m1()
print(D.__mro__)
print(D.mro())
