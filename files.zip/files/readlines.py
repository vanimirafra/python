f=open("2.txt", "r")
print(f.readlines())
f.close()

