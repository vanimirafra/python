class Parent:
    def m1(self):
        print("parent method")

class Child1(Parent):
    def m2(self):
        print("child1 method")

class Child2(Child1):
    def m3(self):
        print("child2 method")
        

obj=Child2()
obj.m3()
obj.m2()
obj.m1()

