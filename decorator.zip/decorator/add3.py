def double(function):
	def wrapper(*args,**kwargs):
		return 2 * function(*args,**kwargs)
	return wrapper

@double
def adder(x,y):
	return x + y
x=int(input("enter number"))
y=int(input("enter number"))
print(adder(x,y))
