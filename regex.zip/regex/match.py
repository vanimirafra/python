import re

result=re.match("h", "hello goodmorning")
if result:
    print("the hai is there")
else:
    print("nothing")


print(result.group(0))