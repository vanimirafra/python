class A:
    def m1(self):
        print("m1 method")
class B(A):
    pass
class c(A):
    pass
class D(A,B):
    pass
obj=D()
obj.m1()


