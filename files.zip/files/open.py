f=open("1.txt","r")
print(f.readlines())
