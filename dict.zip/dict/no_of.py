import yaml
with open("/home/mirafra/Downloads/Ticket/no_of_passengers.yml", 'r') as stream:
    data = yaml.safe_load(stream)
print(data)    
