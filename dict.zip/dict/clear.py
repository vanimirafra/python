d={1:'hi',2:'hai'}
d.clear()
print(d)
